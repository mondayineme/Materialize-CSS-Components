# General Contributing Guidelines

The Material Components contributing policies and procedures can be found in the main Material Components documentation repository’s [contributing page](https://github.com/material-components/material-components/blob/develop/CONTRIBUTING.md).

## $platform-specific Additions

The $platform team also abides by the following policy items. 

### $platformSpecificContent
